***************************************************************************************************************
                                                                                                             
  This work is licensed under the Creative Commons Attribution-NonCommercial-ShareAlike 3.0 Unported License. 
  To view a copy of this license, visit http://creativecommons.org/licenses/by-nc-sa/3.0/ or send a letter    
  to Creative Commons, 444 Castro Street, Suite 900, Mountain View, California, 94041, USA.

***************************************************************************************************************

This package is intendended to contain a dataset for empirical evaluation of Autocompletion Systems, in the 
E-Commerce Domain. The dataset has been designed for two kinds of evaluation: efficiency and effectiveness.
The effectiveness dataset is composed by exploratives, targeted and mixed queries.

The package contains the following directory tree:
- effectiveness
	- exploratives.csv
	- mixed.csv
	- targeted.csv
	- effectiveness-listing.csv
- efficiency
	- efficiency_query_set.txt
	- efficiency-listing.csv

Follows a brief explanation of the contained files.

--------------------------------------------------------------------------------------------------------------
                                       1) exploratives.csv, mixed.csv, targeted.csv
--------------------------------------------------------------------------------------------------------------
This files' content is CSV (| separated) formatted. The format is specified as follows:
|query|
|completion|description|relevance rate|
 
--------------------------------------------------------------------------------------------------------------
                                        2) efficiency_query_set.txt                                           
--------------------------------------------------------------------------------------------------------------
This file contains 199 different lenght queries, each on a different line.

--------------------------------------------------------------------------------------------------------------
                                        3) efficiency-listing and effectiveness-listing.csv                  
--------------------------------------------------------------------------------------------------------------
The listing files are CSV formatted, that is, "|" separated values and lines. Each line's format is specified 
as follows:
ITEM NAME | ITEM POPULARITY | ITEM CATEGORY | ITEM FACETS
